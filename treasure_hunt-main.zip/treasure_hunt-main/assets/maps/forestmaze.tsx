<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="puny wrld" tilewidth="16" tileheight="16" tilecount="1755" columns="27">
 <image source="../Tilemap/punyworld-overworld-tileset.png" width="432" height="1040"/>
</tileset>
